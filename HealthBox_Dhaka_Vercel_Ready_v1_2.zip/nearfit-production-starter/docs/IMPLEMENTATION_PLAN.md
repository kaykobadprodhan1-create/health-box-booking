# Implementation plan

## Sprint 0 — Foundations
- Repository, CI, environments, secrets and migration pipeline
- Design review and Figma componentization
- Threat model and data protection review

## Sprint 1 — Identity and directory
- OTP provider integration
- User and role model
- Admin venue creation
- Owner self-registration and claim requests
- Verification queue

## Sprint 2 — Discovery
- PostGIS nearby search
- Category, radius, area and price filters
- Customer venue details
- English/Bangla content

## Sprint 3 — Inventory and booking
- Service, schedule and slot inventory
- Booking request
- Owner approval and rejection
- Expiry worker and slot locking
- Customer booking history

## Sprint 4 — Payments and ledger
- Merchant gateway integration
- Signed callbacks and idempotency
- Double-entry ledger
- Commission and venue payable
- Refund and settlement workflows

## Sprint 5 — Launch hardening
- QA automation, accessibility and load testing
- Penetration test and remediation
- Data import verification
- Support and operations training
- Staged launch

## Release gates
No public release until OTP, RBAC, owner isolation, payment verification, booking concurrency, ledger reconciliation, privacy policies, backups, monitoring and support escalation are complete.
