# Security baseline

- Replace demo identity headers with verified OTP authentication and secure session cookies.
- Apply RBAC and venue ownership checks on every owner endpoint.
- Hash OTPs and refresh tokens; never log secrets.
- Rate-limit OTP, login, search and booking endpoints.
- Validate all inputs and use parameterized SQL.
- Use signed short-lived media upload URLs and malware/content checks.
- Verify payment provider signatures and callback authenticity.
- Enforce idempotency on booking, payment and refund mutations.
- Store secrets in a managed secret store, not source control.
- Encrypt backups and test restore procedures.
- Maintain immutable audit events for admin and financial actions.
- Complete privacy/legal review for Bangladesh before collecting customer data.
