# Prototype and design files

Open `apps/web/public/prototype.html` in a browser for the clickable customer, owner and admin prototype. The production web shell is under `apps/web/app`.

SVG frames are under `design/figma/`. Import them into Figma and convert the visual primitives into reusable components. `design/tokens.json` is the source of brand tokens.
