# NearFit API Contract (starter)

Base URL: `/api/v1`

## Categories
`GET /venues/categories`

## Nearby venue discovery
`GET /venues/nearby?latitude=23.79&longitude=90.40&radius_km=5&category=gym&page=1&limit=20`

Returns only approved and active venues. Coordinates are WGS84; radius is kilometers; distance is calculated using PostGIS geography.

## Booking creation
`POST /bookings`
Body: `{ "venue_id": "...", "service_id": "...", "slot_id": "...", "quantity": 1 }`

Backend reads slot price and venue from database. Client-submitted prices are never trusted.

## Owner decision
`POST /partner/bookings/{id}/approve`
`POST /partner/bookings/{id}/reject`

Only a verified owner authorized for that venue may make a decision. Starter uses a development-only identity header; replace it with authenticated principal and RBAC guards.

## Payment
Payment initialization must be available only after owner approval. A successful browser redirect is not proof of payment. Verify signed provider callbacks server-side and enforce idempotency.

## Error codes
`SLOT_UNAVAILABLE`, `BOOKING_EXPIRED`, `OWNER_NOT_AUTHORIZED`, `PAYMENT_NOT_VERIFIED`, `VENUE_NOT_APPROVED`, `DUPLICATE_REQUEST`.
