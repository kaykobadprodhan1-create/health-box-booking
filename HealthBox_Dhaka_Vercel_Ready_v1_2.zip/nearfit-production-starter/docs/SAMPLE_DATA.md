# HealthBox sample booking fixtures

The SQL seed `database/seeds/002_sample_booking_data.sql` creates three fictional test venues:

| Venue | Category | Area | Sample price |
|---|---|---|---:|
| HealthBox Demo Gym | Gym | Gulshan | BDT 1,200 |
| HealthBox Demo Swimming Pool | Swimming Pool | Banani | BDT 700 |
| HealthBox Demo Turf | Turf | Bashundhara | BDT 3,500 |

Each fixture includes a venue owner, service, cover image URL, and seven days of inventory with two one-hour sessions per day (08:00 and 18:00 Asia/Dhaka). The seed also creates one demo customer.

These are fictional records for local/staging testing. Prices and image URLs are illustrative; they are not verified venues or live inventory.

## Demo IDs
- Customer: `10000000-0000-4000-8000-000000000001`
- Gym owner: `20000000-0000-4000-8000-000000000011`
- Swimming pool owner: `20000000-0000-4000-8000-000000000012`
- Turf owner: `20000000-0000-4000-8000-000000000013`

Do not use demo identity headers or sample accounts in production.
