# Frontend routes
- `/` — Customer discovery homepage (GPS permission, manual Dhaka area, radius, category and search controls).
- `/partner` — Venue owner dashboard UI starter.
- `/admin` — Super Admin dashboard UI starter.
- `/prototype.html` — Clickable combined customer/owner/admin UX prototype.

Partner and admin routes currently display sample metrics and prototype actions. Connect them to authenticated API endpoints and replace sample data before production.
