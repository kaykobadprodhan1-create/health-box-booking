# HealthBox Dhaka — Production Starter

A developer handover starter for the Dhaka fitness and sports booking marketplace.

## Included
- Clickable responsive UI prototype (`apps/web/public/prototype.html`)
- Figma-importable SVG screen assets and design tokens (`design/`, `apps/web/public/figma-assets/`)
- PostgreSQL + PostGIS schema migration and Dhaka area/category seed data
- NestJS API starter with venue discovery and owner booking approval endpoints
- Next.js bilingual frontend shell
- Docker Compose for PostgreSQL/PostGIS, Redis, API and web
- OpenAPI starter specification and implementation notes

## Business rules encoded
- Launch geography: Dhaka City
- Categories: Gym, Swimming Pool, Turf
- Default discovery radius: 5 km
- English and Bangla
- Free venue registration
- Owner approval required
- Customer payment only after owner approval
- 15% commission on the configured commissionable amount
- Admin-created and owner self-registered venues; both require admin verification

## Important implementation status
This is an executable engineering starter, not a launched production service. Payment gateway credentials, SMS/OTP provider, production secrets, merchant settlement approval, verified venue data, legal policies, Figma workspace publishing and full QA remain deployment tasks. Payment endpoints are deliberately not wired to a real provider.

## Requirements
- Docker + Docker Compose
- Node.js 20+
- npm 10+

## Quick start (Docker)
1. Copy `.env.example` to `.env` and replace every secret.
2. Run `docker compose up --build`.
3. API health: http://localhost:4000/api/v1/health
4. Web app: http://localhost:3000
5. Interactive prototype: http://localhost:3000/prototype.html

The PostgreSQL container runs the schema and seed SQL on first initialization of an empty volume. For manual migration:
`docker compose exec api npm run db:migrate`

## Local development
### Database
`docker compose up -d db redis`

### API
`cd apps/api && npm install && npm run db:migrate && npm run start:dev`

### Web
`cd apps/web && npm install && npm run dev`

## Database migration
`database/migrations/001_initial_schema.sql` creates PostGIS-backed schema, indexes, constraints, status history, audit logs, financial ledger and booking inventory. `database/seeds/001_reference_data.sql` inserts categories and example Dhaka areas.

## API
Base path: `/api/v1`
- `GET /health`
- `GET /api/v1/venues/categories`
- `GET /api/v1/venues/nearby?latitude=23.7937&longitude=90.4066&radius_km=5`
- `POST /api/v1/bookings` (authenticated customer in production)
- `POST /api/v1/partner/bookings/:id/approve`
- `POST /api/v1/partner/bookings/:id/reject`

The starter API includes a development-only demo identity header. Remove it and implement OTP/session authentication before any public deployment.

## Figma handoff
Import SVGs from `design/figma/` into Figma (File → Place image or drag SVG into a canvas). `design/tokens.json` contains colors, typography, spacing and component guidance. `design/FIGMA_HANDOFF.md` describes frames and interactions. SVG imports are visual starting points; editable Figma components should be recreated/organized by the design team.

## Production launch checklist
- Replace demo identity middleware with OTP authentication and secure sessions.
- Implement RBAC and ownership checks on every protected endpoint.
- Integrate an approved Bangladesh payment gateway and verify signed callbacks.
- Implement ledger posting, reconciliation, refund and settlement workflows.
- Configure SMS, email and web-push providers.
- Complete privacy, consumer protection, tax, cancellation and partner agreements.
- Import only verified/authorized venue data.
- Add automated tests, load tests, observability, backups and disaster recovery.
- Complete security review and penetration testing.


## Sample booking data (local/staging only)
Run `database/seeds/002_sample_booking_data.sql` after the initial migration and reference seed. It creates one sample gym, one swimming pool and one turf in Dhaka, demo owner/customer records, services, prices, photos and seven days of test slots (08:00 and 18:00 Dhaka time). These are fictional test listings, not real businesses.

Demo customer ID: `10000000-0000-4000-8000-000000000001`
Demo gym owner ID: `20000000-0000-4000-8000-000000000011`
Demo pool owner ID: `20000000-0000-4000-8000-000000000012`
Demo turf owner ID: `20000000-0000-4000-8000-000000000013`

For local/staging only, the current starter API accepts these IDs through `x-demo-user-id` and `x-demo-owner-id` headers. This is not authentication and must not be exposed in production.

## Deploy the web preview to Vercel

The Next.js customer preview is configured for Vercel in `apps/web/vercel.json`.

1. Push this project to a GitHub repository.
2. In Vercel, choose **Add New → Project** and import that repository.
3. Set **Root Directory** to `apps/web` (important for this monorepo).
4. Keep the framework preset as **Next.js**. Vercel will use the included build configuration.
5. Deploy. The generated `*.vercel.app` URL is the shareable preview.

The current customer preview uses sample/demo venue content. It is not connected to a live payment gateway or production booking database. Do not expose the API's development-only demo identity headers in production. Configure production authentication, database access, and payment processing before accepting real bookings.
