BEGIN;

CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS btree_gist;

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name VARCHAR(150) NOT NULL,
  phone VARCHAR(20) NOT NULL UNIQUE,
  email VARCHAR(255),
  preferred_language VARCHAR(5) NOT NULL DEFAULT 'en' CHECK (preferred_language IN ('en','bn')),
  status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (status IN ('active','blocked','pending')),
  phone_verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(40) NOT NULL UNIQUE,
  description TEXT
);

CREATE TABLE IF NOT EXISTS user_roles (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id UUID NOT NULL REFERENCES roles(id) ON DELETE RESTRICT,
  assigned_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  PRIMARY KEY (user_id, role_id)
);

CREATE TABLE IF NOT EXISTS otp_verifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone VARCHAR(20) NOT NULL,
  otp_hash TEXT NOT NULL,
  purpose VARCHAR(30) NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  attempt_count INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count >= 0),
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_otp_phone_created ON otp_verifications(phone, created_at DESC);

CREATE TABLE IF NOT EXISTS venue_categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(30) NOT NULL UNIQUE,
  name_en VARCHAR(80) NOT NULL,
  name_bn VARCHAR(80) NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS dhaka_areas (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name_en VARCHAR(100) NOT NULL,
  name_bn VARCHAR(100),
  slug VARCHAR(120) NOT NULL UNIQUE,
  parent_area_id UUID REFERENCES dhaka_areas(id),
  is_active BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS venue_owners (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE RESTRICT,
  business_name VARCHAR(200),
  legal_name VARCHAR(200),
  contact_phone VARCHAR(20),
  verification_status VARCHAR(30) NOT NULL DEFAULT 'unverified'
    CHECK (verification_status IN ('unverified','submitted','verified','rejected','suspended')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS venues (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID REFERENCES venue_owners(id) ON DELETE SET NULL,
  category_id UUID NOT NULL REFERENCES venue_categories(id),
  area_id UUID REFERENCES dhaka_areas(id),
  name VARCHAR(200) NOT NULL,
  slug VARCHAR(220) NOT NULL UNIQUE,
  description_en TEXT,
  description_bn TEXT,
  phone VARCHAR(20),
  email VARCHAR(255),
  address_en TEXT NOT NULL,
  address_bn TEXT,
  location GEOGRAPHY(POINT, 4326) NOT NULL,
  onboarding_source VARCHAR(20) NOT NULL CHECK (onboarding_source IN ('admin','owner')),
  verification_status VARCHAR(30) NOT NULL DEFAULT 'submitted'
    CHECK (verification_status IN ('draft','submitted','under_review','changes_requested','approved','rejected','suspended','archived')),
  listing_status VARCHAR(20) NOT NULL DEFAULT 'inactive'
    CHECK (listing_status IN ('active','inactive','suspended')),
  approved_at TIMESTAMPTZ,
  approved_by UUID REFERENCES users(id),
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (verification_status <> 'approved' OR approved_at IS NOT NULL)
);
CREATE INDEX IF NOT EXISTS idx_venues_location ON venues USING GIST(location);
CREATE INDEX IF NOT EXISTS idx_venues_category_status ON venues(category_id, verification_status, listing_status);
CREATE INDEX IF NOT EXISTS idx_venues_area ON venues(area_id);
CREATE INDEX IF NOT EXISTS idx_venues_owner ON venues(owner_id);

CREATE TABLE IF NOT EXISTS venue_claim_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_id UUID NOT NULL REFERENCES venues(id),
  owner_id UUID NOT NULL REFERENCES venue_owners(id),
  evidence_note TEXT,
  status VARCHAR(25) NOT NULL DEFAULT 'submitted'
    CHECK (status IN ('submitted','under_review','approved','rejected','withdrawn')),
  reviewed_by UUID REFERENCES users(id),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_claim_venue_status ON venue_claim_requests(venue_id, status);

CREATE TABLE IF NOT EXISTS venue_images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_id UUID NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  alt_en VARCHAR(200),
  alt_bn VARCHAR(200),
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_cover BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS venue_documents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_id UUID NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
  document_type VARCHAR(60) NOT NULL,
  storage_key TEXT NOT NULL,
  verification_status VARCHAR(20) NOT NULL DEFAULT 'pending'
    CHECK (verification_status IN ('pending','verified','rejected')),
  reviewed_by UUID REFERENCES users(id),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS venue_facilities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_id UUID NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
  name_en VARCHAR(100) NOT NULL,
  name_bn VARCHAR(100),
  UNIQUE (venue_id, name_en)
);

CREATE TABLE IF NOT EXISTS venue_operating_hours (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_id UUID NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
  weekday SMALLINT NOT NULL CHECK (weekday BETWEEN 0 AND 6),
  opens_at TIME,
  closes_at TIME,
  is_closed BOOLEAN NOT NULL DEFAULT FALSE,
  UNIQUE (venue_id, weekday),
  CHECK (is_closed OR (opens_at IS NOT NULL AND closes_at IS NOT NULL))
);

CREATE TABLE IF NOT EXISTS venue_services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_id UUID NOT NULL REFERENCES venues(id) ON DELETE CASCADE,
  name_en VARCHAR(150) NOT NULL,
  name_bn VARCHAR(150),
  description_en TEXT,
  description_bn TEXT,
  duration_minutes INTEGER NOT NULL CHECK (duration_minutes > 0),
  capacity INTEGER NOT NULL DEFAULT 1 CHECK (capacity > 0),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS venue_pricing (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id UUID NOT NULL REFERENCES venue_services(id) ON DELETE CASCADE,
  amount_paisa BIGINT NOT NULL CHECK (amount_paisa >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'BDT' CHECK (currency = 'BDT'),
  valid_from DATE NOT NULL DEFAULT CURRENT_DATE,
  valid_until DATE,
  weekday SMALLINT CHECK (weekday BETWEEN 0 AND 6),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (valid_until IS NULL OR valid_until >= valid_from)
);

CREATE TABLE IF NOT EXISTS venue_slot_inventory (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  venue_id UUID NOT NULL REFERENCES venues(id),
  service_id UUID NOT NULL REFERENCES venue_services(id),
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  capacity INTEGER NOT NULL DEFAULT 1 CHECK (capacity > 0),
  available_quantity INTEGER NOT NULL DEFAULT 1 CHECK (available_quantity >= 0),
  price_paisa BIGINT NOT NULL CHECK (price_paisa >= 0),
  status VARCHAR(20) NOT NULL DEFAULT 'available'
    CHECK (status IN ('available','blocked','closed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (ends_at > starts_at),
  CHECK (available_quantity <= capacity),
  UNIQUE (venue_id, service_id, starts_at, ends_at)
);
CREATE INDEX IF NOT EXISTS idx_slot_search ON venue_slot_inventory(venue_id, starts_at, status);

CREATE TABLE IF NOT EXISTS bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_reference VARCHAR(30) NOT NULL UNIQUE,
  customer_id UUID NOT NULL REFERENCES users(id),
  venue_id UUID NOT NULL REFERENCES venues(id),
  service_id UUID NOT NULL REFERENCES venue_services(id),
  slot_id UUID NOT NULL REFERENCES venue_slot_inventory(id),
  starts_at TIMESTAMPTZ NOT NULL,
  ends_at TIMESTAMPTZ NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity > 0),
  gross_amount_paisa BIGINT NOT NULL CHECK (gross_amount_paisa >= 0),
  discount_amount_paisa BIGINT NOT NULL DEFAULT 0 CHECK (discount_amount_paisa >= 0),
  commission_rate NUMERIC(5,2) NOT NULL DEFAULT 15.00 CHECK (commission_rate BETWEEN 0 AND 100),
  commission_amount_paisa BIGINT NOT NULL CHECK (commission_amount_paisa >= 0),
  venue_amount_paisa BIGINT NOT NULL CHECK (venue_amount_paisa >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'BDT' CHECK (currency = 'BDT'),
  status VARCHAR(30) NOT NULL DEFAULT 'PENDING_APPROVAL'
    CHECK (status IN ('PENDING_APPROVAL','APPROVED','REJECTED','AWAITING_PAYMENT','CONFIRMED','PAYMENT_FAILED','EXPIRED','CANCELLED','REFUND_PENDING','REFUNDED','COMPLETED','NO_SHOW')),
  customer_note TEXT,
  approval_deadline TIMESTAMPTZ,
  payment_deadline TIMESTAMPTZ,
  approved_by UUID REFERENCES users(id),
  approved_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (ends_at > starts_at),
  CHECK (discount_amount_paisa <= gross_amount_paisa),
  CHECK (commission_amount_paisa + venue_amount_paisa = gross_amount_paisa - discount_amount_paisa)
);
CREATE INDEX IF NOT EXISTS idx_booking_customer ON bookings(customer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_booking_venue_status ON bookings(venue_id, status, starts_at);
CREATE INDEX IF NOT EXISTS idx_booking_slot_status ON bookings(slot_id, status);

CREATE TABLE IF NOT EXISTS booking_status_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  old_status VARCHAR(30),
  new_status VARCHAR(30) NOT NULL,
  changed_by UUID REFERENCES users(id),
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL REFERENCES bookings(id),
  provider VARCHAR(40) NOT NULL,
  provider_transaction_id VARCHAR(150),
  amount_paisa BIGINT NOT NULL CHECK (amount_paisa > 0),
  currency CHAR(3) NOT NULL DEFAULT 'BDT',
  status VARCHAR(25) NOT NULL DEFAULT 'initiated'
    CHECK (status IN ('initiated','pending','successful','failed','cancelled','refunded')),
  idempotency_key VARCHAR(120) NOT NULL UNIQUE,
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_payment_provider_tx
  ON payments(provider, provider_transaction_id)
  WHERE provider_transaction_id IS NOT NULL;

CREATE TABLE IF NOT EXISTS payment_webhook_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider VARCHAR(40) NOT NULL,
  provider_event_id VARCHAR(180) NOT NULL,
  signature_valid BOOLEAN NOT NULL DEFAULT FALSE,
  payload JSONB NOT NULL,
  processed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(provider, provider_event_id)
);

CREATE TABLE IF NOT EXISTS refunds (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  payment_id UUID NOT NULL REFERENCES payments(id),
  amount_paisa BIGINT NOT NULL CHECK (amount_paisa > 0),
  reason TEXT NOT NULL,
  status VARCHAR(25) NOT NULL DEFAULT 'requested'
    CHECK (status IN ('requested','approved','processing','completed','rejected','failed')),
  provider_refund_id VARCHAR(150),
  processed_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS commission_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL UNIQUE REFERENCES bookings(id),
  commission_rate NUMERIC(5,2) NOT NULL DEFAULT 15.00,
  commission_amount_paisa BIGINT NOT NULL CHECK (commission_amount_paisa >= 0),
  venue_amount_paisa BIGINT NOT NULL CHECK (venue_amount_paisa >= 0),
  status VARCHAR(20) NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','earned','reversed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ledger_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  code VARCHAR(40) NOT NULL UNIQUE,
  name VARCHAR(120) NOT NULL,
  account_type VARCHAR(20) NOT NULL CHECK (account_type IN ('asset','liability','revenue','expense','equity'))
);

CREATE TABLE IF NOT EXISTS ledger_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference VARCHAR(100) NOT NULL UNIQUE,
  source_type VARCHAR(40) NOT NULL,
  source_id UUID,
  description TEXT,
  posted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ledger_entries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id UUID NOT NULL REFERENCES ledger_transactions(id),
  account_id UUID NOT NULL REFERENCES ledger_accounts(id),
  debit_paisa BIGINT NOT NULL DEFAULT 0 CHECK (debit_paisa >= 0),
  credit_paisa BIGINT NOT NULL DEFAULT 0 CHECK (credit_paisa >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK ((debit_paisa = 0) <> (credit_paisa = 0))
);
CREATE INDEX IF NOT EXISTS idx_ledger_entries_account ON ledger_entries(account_id, created_at DESC);

CREATE TABLE IF NOT EXISTS venue_settlements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES venue_owners(id),
  amount_paisa BIGINT NOT NULL CHECK (amount_paisa > 0),
  currency CHAR(3) NOT NULL DEFAULT 'BDT',
  status VARCHAR(20) NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','approved','processing','paid','failed','cancelled')),
  payout_reference VARCHAR(150),
  approved_by UUID REFERENCES users(id),
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS settlement_items (
  settlement_id UUID NOT NULL REFERENCES venue_settlements(id),
  booking_id UUID NOT NULL REFERENCES bookings(id),
  amount_paisa BIGINT NOT NULL CHECK (amount_paisa > 0),
  PRIMARY KEY (settlement_id, booking_id),
  UNIQUE (booking_id)
);

CREATE TABLE IF NOT EXISTS reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID NOT NULL UNIQUE REFERENCES bookings(id),
  customer_id UUID NOT NULL REFERENCES users(id),
  venue_id UUID NOT NULL REFERENCES venues(id),
  rating SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  channel VARCHAR(20) NOT NULL CHECK (channel IN ('in_app','sms','email','web_push')),
  template_key VARCHAR(100) NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  sent_at TIMESTAMPTZ,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS support_tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id),
  booking_id UUID REFERENCES bookings(id),
  subject VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'open' CHECK (status IN ('open','in_progress','resolved','closed')),
  assigned_to UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS admin_audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_user_id UUID REFERENCES users(id),
  action VARCHAR(120) NOT NULL,
  entity_type VARCHAR(80) NOT NULL,
  entity_id UUID,
  before_data JSONB,
  after_data JSONB,
  ip_address INET,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS system_settings (
  key VARCHAR(100) PRIMARY KEY,
  value JSONB NOT NULL,
  updated_by UUID REFERENCES users(id),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS idempotency_keys (
  key VARCHAR(120) PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  response_code INTEGER,
  response_body JSONB,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE OR REPLACE FUNCTION prevent_unbalanced_ledger()
RETURNS TRIGGER AS $$
DECLARE
  tx_id UUID;
  debit_total BIGINT;
  credit_total BIGINT;
BEGIN
  tx_id := COALESCE(NEW.transaction_id, OLD.transaction_id);
  SELECT COALESCE(SUM(debit_paisa),0), COALESCE(SUM(credit_paisa),0)
    INTO debit_total, credit_total
    FROM ledger_entries WHERE transaction_id = tx_id;
  IF debit_total <> credit_total THEN
    RAISE EXCEPTION 'Unbalanced ledger transaction %: debit %, credit %', tx_id, debit_total, credit_total;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION enforce_ledger_balance_on_commit()
RETURNS TRIGGER AS $$
BEGIN
  IF (SELECT COALESCE(SUM(debit_paisa),0) FROM ledger_entries WHERE transaction_id = NEW.id)
     <> (SELECT COALESCE(SUM(credit_paisa),0) FROM ledger_entries WHERE transaction_id = NEW.id) THEN
    RAISE EXCEPTION 'Ledger transaction % is not balanced', NEW.id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION check_ledger_transaction_balance()
RETURNS TRIGGER AS $$
DECLARE
  tx_id UUID;
  d BIGINT;
  c BIGINT;
BEGIN
  IF TG_OP = 'DELETE' THEN
    tx_id := OLD.transaction_id;
  ELSE
    tx_id := NEW.transaction_id;
  END IF;
  SELECT COALESCE(SUM(debit_paisa),0), COALESCE(SUM(credit_paisa),0)
    INTO d,c FROM ledger_entries WHERE transaction_id = tx_id;
  IF d <> c THEN
    RAISE EXCEPTION 'Ledger transaction % is unbalanced', tx_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_ledger_balance ON ledger_entries;
CREATE CONSTRAINT TRIGGER trg_ledger_balance
AFTER INSERT OR UPDATE OR DELETE ON ledger_entries
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION check_ledger_transaction_balance();

DROP TRIGGER IF EXISTS trg_users_updated ON users;
CREATE TRIGGER trg_users_updated BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION set_updated_at();
DROP TRIGGER IF EXISTS trg_venues_updated ON venues;
CREATE TRIGGER trg_venues_updated BEFORE UPDATE ON venues FOR EACH ROW EXECUTE FUNCTION set_updated_at();
DROP TRIGGER IF EXISTS trg_bookings_updated ON bookings;
CREATE TRIGGER trg_bookings_updated BEFORE UPDATE ON bookings FOR EACH ROW EXECUTE FUNCTION set_updated_at();

INSERT INTO roles(name, description) VALUES
 ('customer','Customer account'),
 ('venue_owner','Verified venue owner'),
 ('super_admin','Full platform administrator'),
 ('venue_manager','Venue verification and management'),
 ('booking_manager','Booking operations'),
 ('finance_manager','Financial operations'),
 ('support_agent','Customer and partner support'),
 ('content_manager','Content and promotions')
ON CONFLICT(name) DO NOTHING;

INSERT INTO ledger_accounts(code,name,account_type) VALUES
 ('PAYMENT_CLEARING','Payment clearing','asset'),
 ('VENUE_PAYABLE','Venue payable','liability'),
 ('NEARFIT_COMMISSION','NearFit commission revenue','revenue'),
 ('REFUND_LIABILITY','Refund liability','liability'),
 ('GATEWAY_FEES','Payment gateway fees','expense')
ON CONFLICT(code) DO NOTHING;

INSERT INTO system_settings(key,value) VALUES
 ('commission_rate', '{"value":15.00,"unit":"percent"}'::jsonb),
 ('default_radius_km', '{"value":5}'::jsonb),
 ('owner_approval_minutes', '{"value":30}'::jsonb),
 ('payment_window_minutes', '{"value":10}'::jsonb),
 ('default_currency', '{"value":"BDT"}'::jsonb),
 ('supported_languages', '["en","bn"]'::jsonb)
ON CONFLICT(key) DO NOTHING;

COMMIT;
