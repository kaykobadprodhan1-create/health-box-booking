-- HealthBox Dhaka sample booking data.
-- Safe to re-run. Sample users are for local/staging only; replace before production.
INSERT INTO users(id,full_name,phone,email,preferred_language,status,phone_verified_at)
VALUES
 ('10000000-0000-4000-8000-000000000001','HealthBox Demo Customer','+8801700000001','customer.demo@healthbox.test','en','active',NOW()),
 ('10000000-0000-4000-8000-000000000011','Gym Demo Owner','+8801700000011','gym.owner@healthbox.test','en','active',NOW()),
 ('10000000-0000-4000-8000-000000000012','Pool Demo Owner','+8801700000012','pool.owner@healthbox.test','en','active',NOW()),
 ('10000000-0000-4000-8000-000000000013','Turf Demo Owner','+8801700000013','turf.owner@healthbox.test','en','active',NOW())
ON CONFLICT(id) DO NOTHING;

INSERT INTO user_roles(user_id,role_id)
SELECT u.id,r.id FROM users u CROSS JOIN roles r
WHERE u.id IN (
 '10000000-0000-4000-8000-000000000001',
 '10000000-0000-4000-8000-000000000011',
 '10000000-0000-4000-8000-000000000012',
 '10000000-0000-4000-8000-000000000013'
) AND r.name = CASE WHEN u.id='10000000-0000-4000-8000-000000000001' THEN 'customer' ELSE 'venue_owner' END
ON CONFLICT DO NOTHING;

INSERT INTO venue_owners(id,user_id,business_name,legal_name,contact_phone,verification_status)
VALUES
 ('20000000-0000-4000-8000-000000000011','10000000-0000-4000-8000-000000000011','Demo Gym Ltd','Demo Gym Ltd','+8801700000011','verified'),
 ('20000000-0000-4000-8000-000000000012','10000000-0000-4000-8000-000000000012','Demo Aquatics Ltd','Demo Aquatics Ltd','+8801700000012','verified'),
 ('20000000-0000-4000-8000-000000000013','10000000-0000-4000-8000-000000000013','Demo Turf Ltd','Demo Turf Ltd','+8801700000013','verified')
ON CONFLICT(id) DO NOTHING;

INSERT INTO venues(
 id,owner_id,category_id,area_id,name,slug,description_en,description_bn,phone,
 address_en,address_bn,location,onboarding_source,verification_status,listing_status,approved_at,approved_by,created_by
)
SELECT v.id,v.owner_id,c.id,a.id,v.name,v.slug,v.description_en,v.description_bn,v.phone,
       v.address_en,v.address_bn,ST_SetSRID(ST_MakePoint(v.lon,v.lat),4326)::geography,
       'admin','approved','active',NOW(),'10000000-0000-4000-8000-000000000011',
       '10000000-0000-4000-8000-000000000011'
FROM (VALUES
 ('30000000-0000-4000-8000-000000000011'::uuid,'20000000-0000-4000-8000-000000000011'::uuid,'gym','gulshan','HealthBox Demo Gym','healthbox-demo-gym','Sample gym for testing the complete booking flow.','সম্পূর্ণ বুকিং ফ্লো পরীক্ষার জন্য নমুনা জিম।','+8801700000011','Road 11, Gulshan 1, Dhaka','রোড ১১, গুলশান ১, ঢাকা',90.4152::double precision,23.7937::double precision),
 ('30000000-0000-4000-8000-000000000012'::uuid,'20000000-0000-4000-8000-000000000012'::uuid,'swimming_pool','banani','HealthBox Demo Swimming Pool','healthbox-demo-pool','Sample swimming pool with hourly sessions.','ঘণ্টাভিত্তিক সেশনের নমুনা সুইমিং পুল।','+8801700000012','Road 12, Banani, Dhaka','রোড ১২, বনানী, ঢাকা',90.4140::double precision,23.7990::double precision),
 ('30000000-0000-4000-8000-000000000013'::uuid,'20000000-0000-4000-8000-000000000013'::uuid,'turf','bashundhara','HealthBox Demo Turf','healthbox-demo-turf','Sample football turf with one-hour slots.','এক ঘণ্টার স্লটসহ নমুনা ফুটবল টার্ফ।','+8801700000013','Block C, Bashundhara R/A, Dhaka','ব্লক সি, বসুন্ধরা আবাসিক এলাকা, ঢাকা',90.4250::double precision,23.8150::double precision)
) AS v(id,owner_id,category_code,area_slug,name,slug,description_en,description_bn,phone,address_en,address_bn,lon,lat)
JOIN venue_categories c ON c.code=v.category_code
LEFT JOIN dhaka_areas a ON a.slug=v.area_slug
ON CONFLICT(id) DO NOTHING;

INSERT INTO venue_images(venue_id,image_url,alt_en,is_cover,sort_order)
VALUES
 ('30000000-0000-4000-8000-000000000011','https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1200&q=80','Demo gym interior',TRUE,0),
 ('30000000-0000-4000-8000-000000000012','https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&w=1200&q=80','Demo swimming pool',TRUE,0),
 ('30000000-0000-4000-8000-000000000013','https://images.unsplash.com/photo-1522778119026-d647f0596c20?auto=format&fit=crop&w=1200&q=80','Demo football turf',TRUE,0)
ON CONFLICT DO NOTHING;

INSERT INTO venue_services(id,venue_id,name_en,name_bn,description_en,duration_minutes,capacity,is_active)
VALUES
 ('40000000-0000-4000-8000-000000000011','30000000-0000-4000-8000-000000000011','Gym day pass','জিম ডে পাস','Single visit access',60,8,TRUE),
 ('40000000-0000-4000-8000-000000000012','30000000-0000-4000-8000-000000000012','Swimming session','সাঁতারের সেশন','One-hour swimming session',60,6,TRUE),
 ('40000000-0000-4000-8000-000000000013','30000000-0000-4000-8000-000000000013','Football turf booking','ফুটবল টার্ফ বুকিং','One-hour turf booking',60,1,TRUE)
ON CONFLICT(id) DO NOTHING;

INSERT INTO venue_pricing(service_id,amount_paisa,currency,valid_from)
VALUES
 ('40000000-0000-4000-8000-000000000011',120000,'BDT',CURRENT_DATE),
 ('40000000-0000-4000-8000-000000000012',70000,'BDT',CURRENT_DATE),
 ('40000000-0000-4000-8000-000000000013',350000,'BDT',CURRENT_DATE)
ON CONFLICT DO NOTHING;

-- Create testable slots for the next 7 days, 08:00–09:00 and 18:00–19:00 Dhaka time.
INSERT INTO venue_slot_inventory(venue_id,service_id,starts_at,ends_at,capacity,available_quantity,price_paisa,status)
SELECT s.venue_id,s.service_id,
       ((d.day_date::timestamp + s.start_time) AT TIME ZONE 'Asia/Dhaka'),
       ((d.day_date::timestamp + s.start_time + INTERVAL '1 hour') AT TIME ZONE 'Asia/Dhaka'),
       s.capacity,s.capacity,s.price_paisa,'available'
FROM (
  VALUES
   ('30000000-0000-4000-8000-000000000011'::uuid,'40000000-0000-4000-8000-000000000011'::uuid,8::int,120000::bigint),
   ('30000000-0000-4000-8000-000000000012'::uuid,'40000000-0000-4000-8000-000000000012'::uuid,6::int,70000::bigint),
   ('30000000-0000-4000-8000-000000000013'::uuid,'40000000-0000-4000-8000-000000000013'::uuid,1::int,350000::bigint)
) s(venue_id,service_id,capacity,price_paisa)
CROSS JOIN generate_series(CURRENT_DATE + 1, CURRENT_DATE + 7, INTERVAL '1 day') AS d(day_date)
CROSS JOIN (VALUES (TIME '08:00'),(TIME '18:00')) AS t(start_time)
ON CONFLICT(venue_id,service_id,starts_at,ends_at) DO NOTHING;

-- Demo account IDs are fixed for local/staging integration tests.
-- Owner IDs expected by development-only API headers:
-- Gym: 20000000-0000-4000-8000-000000000011
-- Pool: 20000000-0000-4000-8000-000000000012
-- Turf: 20000000-0000-4000-8000-000000000013
-- Customer: 10000000-0000-4000-8000-000000000001
