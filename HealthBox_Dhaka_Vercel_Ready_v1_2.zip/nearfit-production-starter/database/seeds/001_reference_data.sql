INSERT INTO venue_categories(code,name_en,name_bn) VALUES
 ('gym','Gym','জিম'),
 ('swimming_pool','Swimming Pool','সুইমিং পুল'),
 ('turf','Turf','টার্ফ')
ON CONFLICT(code) DO NOTHING;

INSERT INTO dhaka_areas(name_en,name_bn,slug) VALUES
 ('Gulshan','গুলশান','gulshan'),
 ('Banani','বনানী','banani'),
 ('Baridhara','বারিধারা','baridhara'),
 ('Bashundhara','বসুন্ধরা','bashundhara'),
 ('Dhanmondi','ধানমন্ডি','dhanmondi'),
 ('Uttara','উত্তরা','uttara'),
 ('Mirpur','মিরপুর','mirpur'),
 ('Mohammadpur','মোহাম্মদপুর','mohammadpur'),
 ('Tejgaon','তেজগাঁও','tejgaon'),
 ('Badda','বাড্ডা','badda'),
 ('Rampura','রামপুরা','rampura'),
 ('Motijheel','মতিঝিল','motijheel'),
 ('Paltan','পল্টন','paltan'),
 ('Ramna','রমনা','ramna'),
 ('Shahbag','শাহবাগ','shahbag'),
 ('Wari','ওয়ারী','wari'),
 ('Khilgaon','খিলগাঁও','khilgaon'),
 ('Jatrabari','যাত্রাবাড়ী','jatrabari'),
 ('Farmgate','ফার্মগেট','farmgate'),
 ('Pallabi','পল্লবী','pallabi'),
 ('Adabor','আদাবর','adabor'),
 ('Kalabagan','কলাবাগান','kalabagan'),
 ('Lalbagh','লালবাগ','lalbagh')
ON CONFLICT(slug) DO NOTHING;
