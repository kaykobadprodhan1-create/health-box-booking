import { Controller, Get, Inject } from '@nestjs/common';
import { Pool } from 'pg';

@Controller()
export class HealthController {
  constructor(@Inject('PG_POOL') private readonly db: Pool) {}

  @Get('/health')
  async health() {
    await this.db.query('SELECT 1');
    return { status: 'ok', service: 'healthbox-api', timestamp: new Date().toISOString() };
  }
}
