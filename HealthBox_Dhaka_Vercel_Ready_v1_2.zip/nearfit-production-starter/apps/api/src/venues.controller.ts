import { BadRequestException, Controller, Get, Inject, Query } from '@nestjs/common';
import { Pool } from 'pg';

@Controller('venues')
export class VenuesController {
  constructor(@Inject('PG_POOL') private readonly db: Pool) {}

  @Get('nearby')
  async nearby(
    @Query('latitude') latitude: string,
    @Query('longitude') longitude: string,
    @Query('radius_km') radiusKm = '5',
    @Query('category') category?: string,
    @Query('page') page = '1',
    @Query('limit') limit = '20'
  ) {
    const lat = Number(latitude), lon = Number(longitude), radius = Number(radiusKm);
    const p = Math.max(1, Number(page) || 1), take = Math.min(50, Math.max(1, Number(limit) || 20));
    if (!Number.isFinite(lat) || lat < -90 || lat > 90 ||
        !Number.isFinite(lon) || lon < -180 || lon > 180 ||
        !Number.isFinite(radius) || radius <= 0 || radius > 50) {
      throw new BadRequestException('Valid latitude, longitude and radius_km are required');
    }
    const values: any[] = [lon, lat, radius * 1000];
    let categorySql = '';
    if (category) { values.push(category); categorySql = ` AND c.code = $${values.length}`; }
    values.push(take, (p - 1) * take);
    const sql = `
      SELECT v.id, v.name, v.slug, v.address_en, v.address_bn,
             c.code AS category, a.name_en AS area,
             ST_Distance(v.location, ST_SetSRID(ST_MakePoint($1,$2),4326)::geography)/1000 AS distance_km
      FROM venues v
      JOIN venue_categories c ON c.id = v.category_id
      LEFT JOIN dhaka_areas a ON a.id = v.area_id
      WHERE v.verification_status='approved' AND v.listing_status='active'
        AND ST_DWithin(v.location, ST_SetSRID(ST_MakePoint($1,$2),4326)::geography, $3)
        ${categorySql}
      ORDER BY distance_km ASC
      LIMIT $${values.length - 1} OFFSET $${values.length}`;
    const result = await this.db.query(sql, values);
    return { success: true, data: result.rows, meta: { page: p, limit: take, radius_km: radius } };
  }

  @Get('categories')
  async categories() {
    const result = await this.db.query('SELECT id, code, name_en, name_bn FROM venue_categories WHERE is_active=true ORDER BY name_en');
    return { success: true, data: result.rows };
  }
}
