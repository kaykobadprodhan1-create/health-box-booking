import { Module } from '@nestjs/common';
import { Pool } from 'pg';
import { HealthController } from './health.controller';
import { VenuesController } from './venues.controller';
import { BookingsController } from './bookings.controller';

@Module({
  controllers: [HealthController, VenuesController, BookingsController],
  providers: [{
    provide: 'PG_POOL',
    useFactory: () => new Pool({ connectionString: process.env.DATABASE_URL, max: 15 })
  }]
})
export class AppModule {}
