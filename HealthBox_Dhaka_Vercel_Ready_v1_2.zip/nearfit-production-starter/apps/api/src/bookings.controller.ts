import { Body, ConflictException, Controller, Headers, Inject, NotFoundException, Param, Post } from '@nestjs/common';
import { Pool } from 'pg';

@Controller()
export class BookingsController {
  constructor(@Inject('PG_POOL') private readonly db: Pool) {}

  // DEVELOPMENT STARTER ONLY: replace x-demo-user-id with authenticated principal from OTP/session guard.
  @Post('bookings')
  async create(@Body() body: any, @Headers('x-demo-user-id') customerId?: string) {
    if (!customerId) throw new ConflictException('Authentication required. Demo identity header is development-only.');
    const client = await this.db.connect();
    try {
      await client.query('BEGIN');
      const slot = await client.query(
        `SELECT s.*, v.id AS venue_id, v.verification_status, v.listing_status
         FROM venue_slot_inventory s JOIN venues v ON v.id=s.venue_id
         WHERE s.id=$1 FOR UPDATE`, [body.slot_id]);
      if (!slot.rowCount) throw new NotFoundException('Slot not found');
      const s = slot.rows[0];
      if (s.verification_status !== 'approved' || s.listing_status !== 'active' ||
          s.status !== 'available' || s.available_quantity < (Number(body.quantity) || 1)) {
        throw new ConflictException('Slot unavailable');
      }
      const qty = Number(body.quantity) || 1;
      const gross = Number(s.price_paisa) * qty;
      const rate = Number(process.env.COMMISSION_RATE || 15);
      const commission = Math.round(gross * rate / 100);
      const reference = `NF-${new Date().getFullYear()}-${Date.now().toString().slice(-8)}`;
      const booking = await client.query(
        `INSERT INTO bookings
         (booking_reference,customer_id,venue_id,service_id,slot_id,starts_at,ends_at,quantity,
          gross_amount_paisa,commission_rate,commission_amount_paisa,venue_amount_paisa,status,
          approval_deadline,customer_note)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,'PENDING_APPROVAL',NOW()+INTERVAL '30 minutes',$13)
         RETURNING id,booking_reference,status,gross_amount_paisa`,
        [reference, customerId, s.venue_id, s.service_id, s.id, s.starts_at, s.ends_at, qty,
         gross, rate, commission, gross-commission, body.customer_note || null]);
      await client.query(`INSERT INTO booking_status_history(booking_id,new_status,changed_by) VALUES($1,'PENDING_APPROVAL',$2)`, [booking.rows[0].id, customerId]);
      await client.query('COMMIT');
      return { success: true, data: booking.rows[0] };
    } catch (e) {
      await client.query('ROLLBACK');
      throw e;
    } finally { client.release(); }
  }

  @Post('partner/bookings/:id/approve')
  async approve(@Param('id') id: string, @Headers('x-demo-owner-id') ownerId?: string) {
    if (!ownerId) throw new ConflictException('Owner authentication required');
    const client = await this.db.connect();
    try {
      await client.query('BEGIN');
      const result = await client.query(
        `SELECT b.*, v.owner_id, s.available_quantity
         FROM bookings b JOIN venues v ON v.id=b.venue_id
         JOIN venue_slot_inventory s ON s.id=b.slot_id
         WHERE b.id=$1 FOR UPDATE OF b,s`, [id]);
      if (!result.rowCount) throw new NotFoundException('Booking not found');
      const b = result.rows[0];
      if (b.owner_id !== ownerId) throw new ConflictException('Not authorized for this venue');
      if (b.status !== 'PENDING_APPROVAL') throw new ConflictException('Booking is not awaiting approval');
      if (new Date(b.approval_deadline) < new Date()) throw new ConflictException('Approval window expired');
      if (Number(b.available_quantity) < Number(b.quantity)) throw new ConflictException('Slot no longer available');
      await client.query(
        `UPDATE bookings SET status='AWAITING_PAYMENT', approved_at=NOW(),
         payment_deadline=NOW()+INTERVAL '10 minutes' WHERE id=$1`, [id]);
      await client.query(
        `UPDATE venue_slot_inventory SET available_quantity=available_quantity-$2 WHERE id=$1`, [b.slot_id,b.quantity]);
      await client.query(
        `INSERT INTO booking_status_history(booking_id,old_status,new_status) VALUES($1,'PENDING_APPROVAL','AWAITING_PAYMENT')`, [id]);
      await client.query('COMMIT');
      return { success: true, data: { booking_id: id, status: 'AWAITING_PAYMENT', payment_window_minutes: 10 } };
    } catch (e) { await client.query('ROLLBACK'); throw e; }
    finally { client.release(); }
  }

  @Post('partner/bookings/:id/reject')
  async reject(@Param('id') id: string, @Body() body: any, @Headers('x-demo-owner-id') ownerId?: string) {
    if (!ownerId) throw new ConflictException('Owner authentication required');
    const client = await this.db.connect();
    try {
      await client.query('BEGIN');
      const result = await client.query(
        `SELECT b.id,b.status,v.owner_id FROM bookings b JOIN venues v ON v.id=b.venue_id WHERE b.id=$1 FOR UPDATE`, [id]);
      if (!result.rowCount) throw new NotFoundException('Booking not found');
      if (result.rows[0].owner_id !== ownerId) throw new ConflictException('Not authorized for this venue');
      if (result.rows[0].status !== 'PENDING_APPROVAL') throw new ConflictException('Booking is not awaiting approval');
      await client.query(`UPDATE bookings SET status='REJECTED' WHERE id=$1`, [id]);
      await client.query(`INSERT INTO booking_status_history(booking_id,old_status,new_status,note) VALUES($1,'PENDING_APPROVAL','REJECTED',$2)`, [id, body.reason || null]);
      await client.query('COMMIT');
      return { success: true, data: { booking_id: id, status: 'REJECTED' } };
    } catch (e) { await client.query('ROLLBACK'); throw e; }
    finally { client.release(); }
  }
}
