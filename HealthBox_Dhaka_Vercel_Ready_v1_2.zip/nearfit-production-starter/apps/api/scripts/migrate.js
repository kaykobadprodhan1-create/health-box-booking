const fs = require('fs');
const path = require('path');
const { Client } = require('pg');

(async () => {
  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();
  try {
    const migration = fs.readFileSync(path.resolve(__dirname, '../../../database/migrations/001_initial_schema.sql'), 'utf8');
    await client.query(migration);
    const seed = fs.readFileSync(path.resolve(__dirname, '../../../database/seeds/001_reference_data.sql'), 'utf8');
    await client.query(seed);
    console.log('HealthBox database migration and reference seeds completed.');
  } finally {
    await client.end();
  }
})().catch(err => { console.error(err); process.exit(1); });
