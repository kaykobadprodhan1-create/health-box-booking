'use client';
import { useState } from 'react';
export default function AdminPage(){
 const [status,setStatus]=useState('Awaiting verification');
 return <main style={{maxWidth:1100,margin:'40px auto',padding:20}}>
  <a href="/" style={{color:'#52734d'}}>← HealthBox home</a>
  <h1>Super Admin Dashboard</h1><p style={{color:'#718078'}}>Venue verification, bookings and financial operations.</p>
  <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))',gap:14}}>
   {[['128','Total venues'],['16','Pending verification'],['342','Booking requests'],['৳1.2L','Sample commission']].map(([n,l])=><div key={l} style={{background:'white',border:'1px solid #e5ebe6',borderRadius:14,padding:18}}><h2>{n}</h2><span>{l}</span></div>)}
  </div>
  <section style={{background:'white',border:'1px solid #e5ebe6',borderRadius:14,padding:20,marginTop:24}}>
   <h2>Venue verification queue</h2>
   {['Power House Fitness · Gym · Banani · Owner application','Blue Wave Aquatics · Swimming Pool · Uttara · Admin listing'].map(x=><div key={x} style={{display:'flex',justifyContent:'space-between',gap:12,alignItems:'center',padding:'16px 0',borderBottom:'1px solid #eee',flexWrap:'wrap'}}><b>{x}</b><button onClick={()=>setStatus('Selected for review')} style={{background:'#b9f36b',padding:10,border:0,borderRadius:8}}>Review</button></div>)}
   <p role="status">{status}. Sample dashboard data only.</p>
  </section>
 </main>
}
