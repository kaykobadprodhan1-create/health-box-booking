'use client';
import { useState } from 'react';
export default function PartnerPage(){
 const [decision,setDecision]=useState('');
 return <main style={{maxWidth:1100,margin:'40px auto',padding:20}}>
  <a href="/" style={{color:'#52734d'}}>← HealthBox home</a>
  <h1>Venue Owner Dashboard</h1><p style={{color:'#718078'}}>Manage venue details, availability and owner-approval booking requests.</p>
  <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))',gap:14}}>
   {[['08','Total bookings'],['03','Pending requests'],['৳24,500','Gross booking value'],['15%','HealthBox commission']].map(([n,l])=><div key={l} style={{background:'white',border:'1px solid #e5ebe6',borderRadius:14,padding:18}}><h2>{n}</h2><span>{l}</span></div>)}
  </div>
  <section style={{background:'white',border:'1px solid #e5ebe6',borderRadius:14,padding:20,marginTop:24}}>
   <h2>Booking requests</h2>
   {['Rahim Ahmed · Goal Zone Turf · 28 Nov · 7 PM–8 PM · ৳3,000','Nusrat Jahan · Aqua Blue Pool · 29 Nov · 5 PM–6 PM · ৳700'].map(x=><div key={x} style={{display:'flex',justifyContent:'space-between',gap:12,alignItems:'center',padding:'16px 0',borderBottom:'1px solid #eee',flexWrap:'wrap'}}><b>{x}</b><div><button onClick={()=>setDecision('Approved (prototype only)')} style={{background:'#b9f36b',padding:10,border:0,borderRadius:8}}>Approve</button> <button onClick={()=>setDecision('Rejected (prototype only)')} style={{padding:10,border:'1px solid #ddd',borderRadius:8}}>Reject</button></div></div>)}
   {decision&&<p role="status">{decision}. Connect the authenticated API to perform this action.</p>}
  </section>
 </main>
}
