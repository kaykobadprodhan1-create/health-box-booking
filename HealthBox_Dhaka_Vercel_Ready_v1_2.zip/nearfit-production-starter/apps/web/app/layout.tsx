import './globals.css';
import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'HealthBox Dhaka', description: 'Discover and book gyms, swimming pools and turfs near you.' };
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) {
  return <html lang="en"><body>{children}</body></html>;
}
