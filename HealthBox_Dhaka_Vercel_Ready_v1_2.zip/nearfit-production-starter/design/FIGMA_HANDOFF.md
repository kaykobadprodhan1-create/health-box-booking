# NearFit Figma UI/UX Handoff

## Import
Import the SVG files in `design/figma/` into Figma using drag-and-drop or File → Place image. They are editable vector artwork after import, but not native Figma component libraries. Recreate repeated elements as components and apply `tokens.json` as Figma variables.

## Frames
- `01-customer-home.svg`: Desktop customer discovery homepage, 1440 × 1100.
- `02-venue-detail.svg`: Venue profile and booking information, 1440 × 1100.
- `03-owner-dashboard.svg`: Owner booking queue and performance overview, 1440 × 1100.
- `04-admin-dashboard.svg`: Admin verification and platform metrics, 1440 × 1100.

## Core prototype interactions
1. Header language switcher toggles English/Bangla.
2. Location control requests browser GPS permission; manual area selection remains available.
3. Category tabs filter Gym, Swimming Pool and Turf.
4. Radius selector supports 2, 5, 10 and 20 km.
5. Venue cards open detail views and booking request flow.
6. Booking request is pending until owner approval.
7. Owner dashboard exposes Approve and Reject actions.
8. Admin dashboard exposes venue verification actions.

## Design rules
- Mobile-first responsive layout.
- Forest green and lime brand palette.
- Strong typography and accessible contrast.
- Venue photography should use authorized venue assets in production.
- Use explicit loading, empty, error and permission-denied states.
- All text must be localized through English/Bangla translation keys.
